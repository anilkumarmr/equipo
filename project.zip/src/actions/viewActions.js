const minimizeSidebar = () => ({
   type: "MINIMIZE_SIDEBAR",
});

const maximizeSidebar = () => ({
   type: "MAXIMIZE_SIDEBAR",
});

export { minimizeSidebar, maximizeSidebar };
